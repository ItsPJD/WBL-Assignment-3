import React, { useState } from 'react';
import { Text, View, Button, TextInput, FlatList } from 'react-native';
import { Linking } from 'react-native';

const ResourceList = ({ navigation, route }) => {
  const [resources, setResources] = useState([
    { id: 1, name: 'Resource 1', link: 'https://www.google.com' },
    { id: 2, name: 'Resource 2', link: 'https://www.youtube.com' },
    { id: 3, name: 'Resource 3', link: 'https://www.wikipedia.com', },
  ]);

  const { favourites, setFavourites } = route.params;

  const addFavourite = (id) => {
  setFavourites((currentFavourites) => {
    const resourceToAdd = resources.find((resource) => resource.id === id);
    return [...currentFavourites, { ...resourceToAdd, notes: '' }];
  });
};

  const renderItem = ({ item }) => (
    <View style={{ flexDirection: 'column'}}>
      <View style={{ flex: 1 }}>
        <Text>{item.name}</Text>
        <Text>{item.link}</Text>
      </View>
      <Button title="Visit" onPress={() => Linking.openURL(item.link)} />
      <Button title="Add to favourites" onPress={() => addFavourite(item.id)} />
    </View>
  );

  return (
    <View>
      <FlatList
        data={resources}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};

export default ResourceList;