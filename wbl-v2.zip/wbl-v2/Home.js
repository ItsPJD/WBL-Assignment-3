import React from 'react';
import { View, Button } from 'react-native';

const Home = ({ navigation }) => {
  return (
    <View>
      <Button
        title="Go to Resource List"
        onPress={() => navigation.navigate('Resource List')}
      />
      <Button
        title="Go to Favourites"
        onPress={() => navigation.navigate('Favourites')}
      />
    </View>
  );
};

export default Home;