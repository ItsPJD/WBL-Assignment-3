import React, { useState } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from './Home';
import ResourceList from './ResourceList';
import Favourites from './Favourites';

const Stack = createStackNavigator();

export default function App() {
  const [favourites, setFavourites] = useState([]);

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Resource List" component={ResourceList} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Favourites" component={Favourites} initialParams={{ favourites, setFavourites }}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}