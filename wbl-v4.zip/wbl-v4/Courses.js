import React, { useState, useEffect } from 'react';
import { View, Button, Text} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Courses = ({ navigation }) => {
  const [selectedCourse, setSelectedCourse] = useState(null);

  useEffect(() => {
    async function getSelectedCourse() {
      const course = await AsyncStorage.getItem('selectedCourse');
      setSelectedCourse(course);
    }
    getSelectedCourse();
  }, []);

  const handleCourseSelection = async (course) => {
    setSelectedCourse(course);
    await AsyncStorage.setItem('selectedCourse', course);
  };

  const handleReset = async () => {
    setSelectedCourse(null);
    await AsyncStorage.removeItem('selectedCourse');
  };

  return (
    <View>
      <Text>
        Select which course you are currently studying
      </Text>
      <Button
        title="Course 1 - Software Development"
        accessibilityHint="Takes you to the software course page, containing its appropriate modules"
        onPress={() => navigation.navigate(`Software Course`)}
        disabled={selectedCourse === 'course2'}
      />
      <Button
        title="Select As Favourite Course"
        accessibilityHint="Press to select this as your current course - this will make other courses unavailable to view until reset"
        onPress={() => handleCourseSelection('course1')}
        disabled={selectedCourse === 'course2'}
      />
      <Button
        title="Course 2 - Networking"
        accessibilityHint="Takes you to the networking course page, containing its appropriate modules"
        onPress={() => navigation.navigate(`Networking Course`)}
        disabled={selectedCourse === 'course1'}
      />
      <Button
        title="Select As Favourite Course"
        accessibilityHint="Press to select this as your current course - this will make other courses unavailable to view until reset"
        onPress={() => handleCourseSelection('course2')}
        disabled={selectedCourse === 'course1'}
      />
      {selectedCourse && (
        <Button
          title="Reset"
          accessibilityHint="Resets what course you have selected, allowing you to select again which course you are studying"
          onPress={() => handleReset()}
        />
      )}
    </View>
  );
};

export default Courses;