import React from 'react';
import { View, Button } from 'react-native';

const Modules2 = ({ navigation }) => {
  return (
    <View>
      <Button
        title="Module 1 - Networking 1"
        accessibilityHint="Takes you to the first networking module page and its relevant assignments"
        onPress={() => navigation.navigate('Networking Module 1')}
      />
      <Button
        title="Module 2 - Networking 2"
        accessibilityHint="Takes you to the second networking module page and its relevant assignments"
        onPress={() => navigation.navigate('Networking Module 2')}
      />
    </View>
  );
};

export default Modules2;