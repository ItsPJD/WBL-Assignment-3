import React from 'react';
import { View, Button } from 'react-native';

const Home = ({ navigation }) => {

  return (
    <View>
      <Button
        title="Go to Courses"
        accessibilityHint="Navigates to the courses page where you can select what course you are studying"
        onPress={() => navigation.navigate('Courses')}
      />
      <Button
        title="Favourite Resources"
        accessibilityHint="Navigates to the saved resources that are added as favourites"
        onPress={() => navigation.navigate('Favourites')}
      />
    </View>
  );
};

export default Home;