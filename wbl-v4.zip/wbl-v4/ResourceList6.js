import React, { useState, useEffect } from 'react';
import { Text, View, Button, FlatList} from 'react-native';
import { Linking } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ResourceList4 = ({ navigation, route }) => {
  const [resources, setResources] = useState([
    { id: 16, name: 'Resource 16', link: 'https://www.google.com' },
    { id: 17, name: 'Resource 17', link: 'https://www.youtube.com' },
    { id: 18, name: 'Resource 18', link: 'https://www.wikipedia.com' },
  ]);
  const [readResources, setReadResources] = useState({});

  useEffect(() => {
    AsyncStorage.getItem('readResources')
      .then(value => {
        if (value) {
          setReadResources(JSON.parse(value));
        }
      })
      .catch(error => console.error(error));
  }, []);

  useEffect(() => {
    AsyncStorage.setItem('readResources', JSON.stringify(readResources))
      .catch(error => console.error(error));
  }, [readResources]);

  const { favourites, setFavourites } = route.params;

  const addFavourite = (id) => {
    setFavourites((currentFavourites) => {
      const resourceToAdd = resources.find((resource) => resource.id === id);
      return [...currentFavourites, { ...resourceToAdd, notes: '' }];
    });
  };

  const markAsRead = (id) => {
    setReadResources((currentReadResources) => {
      return {...currentReadResources, [id]: true};
    });
  };

  const markAllAsUnread = () => {
    setReadResources({});
  };

  const renderItem = ({ item }) => (
    <View style={{ flexDirection: 'column'}}>
      <View style={{ flex: 1 }}>
        <Text>{item.name}</Text>
        <Text>{item.link}</Text>
      </View>
      {readResources[item.id] ? (
        <Button title="Read" accessibilityHint="This resource has been marked as Read" disabled={true} />
      ) : (
        <Button title="Mark as Read" accessibilityHint="Marks this resource as being read, so the user can remember which resources they have interacted with already." onPress={() => markAsRead(item.id)} />
      )}
      <Button title="Visit" accessibilityHint="Opens the URL Link for this resource" onPress={() => Linking.openURL(item.link)} />
      <Button title="Add to favourites" accessibilityHint="Marks this resource as a favourite and saves it to the saved resources page, which is available on the home page." onPress={() => addFavourite(item.id)} />
    </View>
  );

  return (
    <View>
      <Button title="Mark All as Unread" accessibilityHint="Marks all resources on the app as unread" onPress={markAllAsUnread} />
      <FlatList
        data={resources}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};

export default ResourceList4;