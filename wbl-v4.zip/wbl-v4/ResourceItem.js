import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import { Linking } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ResourceItem = ({ item, favourites, setFavourites }) => {
  const [tempNotes, setTempNotes] = useState(item.notes);

  const updateNotes = () => {
    const updatedFavourites = favourites.map((favourite) => {
      if (favourite.id === item.id) {
        return { ...favourite, notes: tempNotes };
      }
      return favourite;
    });
    setFavourites(updatedFavourites);
    AsyncStorage.setItem('favourites', JSON.stringify(updatedFavourites));
  };
  
  useEffect(() => {
    const saveFavouritesToStorage = async () => {
      await AsyncStorage.setItem('favourites', JSON.stringify(favourites));
  };
    saveFavouritesToStorage();
  }, [favourites]);

  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.resourceName}>{item.name}</Text>
        <Button
          style={styles.resourceLink}
          title={item.link}
          onPress={() => Linking.openURL(item.link)}
        />
      </View>
      <View style={{ flexDirection: 'column', alignItems: 'center' }}>
        <TextInput
          style={styles.resourceNotesInput}
          placeholder="Add note"
          value={tempNotes}
          onBlur={updateNotes}
          onChangeText={(text) => setTempNotes(text)}
          multiline={true}
          numberOfLines={6}
          textAlignVertical="top"
        />
        <Button
          style={styles.deleteButton}
          title="Delete"
          onPress={() => {
            const updatedFavourites = favourites.filter(
              (favourite) => favourite.id !== item.id
            );
            setFavourites(updatedFavourites);
            AsyncStorage.setItem('favourites', JSON.stringify(updatedFavourites));
          }}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  resourceName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    justifyContent: 'center',
  },
  resourceLink: {
    color: 'blue',
    marginBottom: 5,
  },
  resourceNotesInput: {
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 5,
    paddingHorizontal: 10,
  },
  deleteButton: {
    backgroundColor: 'red',
    color: 'white',
    fontWeight: 'bold',
    paddingVertical: 5,
    paddingHorizontal: 10,
  },
});

export default ResourceItem;