import React, { useState } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from './Home';
import ResourceList1 from './ResourceList1';
import ResourceList2 from './ResourceList2';
import ResourceList3 from './ResourceList3';
import ResourceList4 from './ResourceList4';
import ResourceList5 from './ResourceList5';
import ResourceList6 from './ResourceList6';
import ResourceList7 from './ResourceList7';
import ResourceList8 from './ResourceList8';
import Assignments1 from './Assignments1';
import Assignments2 from './Assignments2';
import Assignments3 from './Assignments3';
import Assignments4 from './Assignments4';
import Favourites from './Favourites';
import Courses from './Courses';
import Modules1 from './Modules1';
import Modules2 from './Modules2';

const Stack = createStackNavigator();

export default function App() {
  const [favourites, setFavourites] = useState([]);

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Courses" component={Courses} />
        <Stack.Screen name="Software Course" component={Modules1} />
        <Stack.Screen name="Networking Course" component={Modules2} />
        <Stack.Screen name="Software Module 1" component={Assignments1} />
        <Stack.Screen name="Software Module 2" component={Assignments2} />
        <Stack.Screen name="Networking Module 1" component={Assignments3} />
        <Stack.Screen name="Networking Module 2" component={Assignments4} />
        <Stack.Screen name="Resource List 1" component={ResourceList1} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 2" component={ResourceList2} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 3" component={ResourceList3} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 4" component={ResourceList4} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 5" component={ResourceList5} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 6" component={ResourceList6} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 7" component={ResourceList7} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 8" component={ResourceList8} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Favourites" component={Favourites} initialParams={{ favourites, setFavourites }}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
