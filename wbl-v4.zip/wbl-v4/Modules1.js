import React from 'react';
import { View, Button } from 'react-native';

const Modules1 = ({ navigation }) => {
  return (
    <View>
      <Button
        title="Module 1 - Software 1"
        accessibilityHint="Takes you to the first software module page and its relevant assignments"
        onPress={() => navigation.navigate('Software Module 1')}
      />
      <Button
        title="Module 2 - Software 2"
        accessibilityHint="Takes you to the second software module page and its relevant assignments"
        onPress={() => navigation.navigate('Software Module 2')}
      />
    </View>
  );
};

export default Modules1;