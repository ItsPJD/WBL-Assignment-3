import React from 'react';
import { View, Button } from 'react-native';

const Assignments1 = ({ navigation }) => {
  return (
    <View>
      <Button
        title="Assignment 1"
        accessibilityHint="Navigates to the list of resources for assignment 1 of this module"
        onPress={() => navigation.navigate('Resource List 1')}
      />
      <Button
        title="Assignment 2"
        accessibilityHint="Navigates to the list of resources for assignment 2 of this module"
        onPress={() => navigation.navigate('Resource List 2')}
      />
    </View>
  );
};

export default Assignments1;