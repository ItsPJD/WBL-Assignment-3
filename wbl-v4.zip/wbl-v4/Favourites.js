import React, { useState, useEffect } from 'react';
import { View, FlatList } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ResourceItem from './ResourceItem';

const Favourites = ({ route }) => {
  const { favourites, setFavourites } = route.params;
  const [storedFavourites, setStoredFavourites] = useState([]);

  const loadFavourites = async () => {
    const storedFavourites = await AsyncStorage.getItem('favourites');
    if (storedFavourites) {
      setStoredFavourites(JSON.parse(storedFavourites));
    }
  };

  useEffect(() => {
    loadFavourites();
  }, []);

  useEffect(() => {
    if (storedFavourites.length > 0) {
      setFavourites(storedFavourites);
    }
  }, [storedFavourites, setFavourites]);

  return (
    <View>
      <FlatList
        data={favourites}
        renderItem={({ item }) => (
          <ResourceItem
            item={item}
            favourites={favourites}
            setFavourites={setFavourites}
          />
        )}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};


export default Favourites;