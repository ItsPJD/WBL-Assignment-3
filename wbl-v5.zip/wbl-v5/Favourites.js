import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, FlatList } from 'react-native';
import { Linking } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

//importing the appropriate tools and libraries for the favourite resources screen of the app.

const ResourceItem = ({ item, favourites, setFavourites }) => {
  const [tempNotes, setTempNotes] = useState(item.notes);

//defines the ResourceItem component, and sets item, favourites and setFavourites as props. These are used and passed through later in the Favourites component for displaying the Flatlist.
// tempNotes variable is set to an array, in which holds the notes for all resources. setTempNotes is used later on to update and change the data held in the tempNotes array.

  const updateNotes = () => {
    setFavourites(prevFavourites => {
      const updatedFavourites = prevFavourites.map((favourite) => {
        if (favourite.id === item.id) {
          return { ...favourite, notes: tempNotes };
        }
        return favourite;
      });
      AsyncStorage.setItem('favourites', JSON.stringify(updatedFavourites));
      return updatedFavourites;
    });
  };

// the updateNotes function is called whenever the user stops writing a note on a resource, which is achieved with the "onBlur" functionality. This function takes the previously saved favourites data, and uses the .map functionality in order to get the updated state of this array. This then allows for the new updated array to take the new value of the "notes" in the resource that matches the id found from the "item.id", and replaces it with tempNotes, which will contain the newly updated version of the notes for that resource. This then allows for that newly updated note to be saved in the favourites array with its updated state.

  useEffect(() => {
    const saveFavouritesToStorage = async () => {
      await AsyncStorage.setItem('favourites', JSON.stringify(favourites));
  };
    saveFavouritesToStorage();
  }, [favourites]);

// this useEffect hook is called whenever the "favourites" array is changed. This then allows for the favourites array to be saved in AsyncStorage whenever the array is updated, meaning that multiple resources can be saved when adding them in one go, as well as be able to save resources that the user does not interact with their notes with before exiting out of the favourites page.

  return (
    <View style={styles.container}>

      <View>
        <Text style={styles.resourceName}>{item.name}</Text>
      </View>
      <View style={styles.resourceLink}>
        <Button
          style={styles.resourceLink}
          accessibilityHint="Opens the URL Link for this resource"
          title={item.link}
          onPress={() => Linking.openURL(item.link)}
        />
      </View>

      <View style={styles.input}>
        <TextInput
          placeholder="Add note"
          accessibilityHint="Note for this resource. Type here to add and save a note"
          value={tempNotes}
          onBlur={updateNotes}
          onChangeText={(text) => setTempNotes(text)}
          multiline={true}
          numberOfLines={6}
          textAlignVertical="top"
        />
      </View>
      <View style ={styles.deleteButton}>
        <Button
          color="red"
          title="Delete"
          accessibilityHint="Deletes this resource from the saved resources page"
          onPress={() => {
            const updatedFavourites = favourites.filter(
              (favourite) => favourite.id !== item.id
            );
            setFavourites(updatedFavourites);
            AsyncStorage.setItem('favourites', JSON.stringify(updatedFavourites));
          }}
        />
      </View>
    </View>
  );
};

//The return function for the ResourceItem component. Each resource, using their item id, is passed through this return statement, which acts as the renderItem for the Flatlist in the Favourites component, allowing the user to view each resource. This displays the saved resources' name, a button to visit the URL link for that resource, a notes box for that resource that the user can save notes to for independent study, as well as a delete button that lets the user delete a resource from the favourite resources screen.

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  resourceName: {
    marginTop: 16,
    paddingVertical: 8,
    borderWidth: 3,
    borderColor: 'black',
    borderRadius: 3,
    backgroundColor: 'black',
    color: 'white',
    textAlign: 'center',
    fontSize: 30,
    fontWeight: 'bold',
  },
  resourceLink: {
    backgroundColor: 'white',
    fontWeight: 'bold',
    paddingVertical: 5,
    paddingHorizontal: 10,
    height: 50,
    margin: 6,
    borderWidth: 1,
    padding: 10,
  },

  deleteButton: {
    backgroundColor: 'white',
    fontWeight: 'bold',
    paddingVertical: 5,
    paddingHorizontal: 10,
    height: 50,
    margin: 6,
    borderWidth: 1,
    padding: 10,
    borderColor: 'red',
  },
  input: {
    height: 80,
    margin: 6,
    borderWidth: 2,
    padding: 10,
  },
});

//Stylesheet for the return function of the ResourceItem component. This stylesheet is used to design the aesthetic of each resource found in the favourite resources page, and includes font sizes, borders for buttons, colour scheme, the design of the notes box and borders, etc. 

const Favourites = ({ route }) => {
  const { favourites, setFavourites } = route.params;
  const [storedFavourites, setStoredFavourites] = useState([]);

// defines the Favourites component, and uses "route" as a prop. The favourites and setFavourites variables are then destructured with route.params, which enables these variables to be accessed in other screens using the Stack Navigator in the App.js file.
// storedFavourites and setStoredFavourites variables are set to an empty array, so that they can be used later to set the favourites array to be equal to the data needed for the resources that are saved in that array for rendering each resource in the resourceItem component.

  useEffect(() => {
  const loadFavourites = async () => {
    const storedFavourites = await AsyncStorage.getItem('favourites');
    if (storedFavourites) {
      setStoredFavourites(JSON.parse(storedFavourites));
    }
  };
    loadFavourites();
  }, []);

  useEffect(() => {
    if (storedFavourites.length > 0) {
      setFavourites(storedFavourites);
    }
  }, [storedFavourites, setFavourites]);

// The first useEffect hook is called when the component mounts and loads the stored favourites (the resources saved in the favourites array) from out of AsyncStorage. If those stored favourites are correctly found, then it will set storedFavourites with the stored favourites found, using JSON.parse to change them from a string (which is used to save data to AsyncStorage) back to javascript objects.

//The second useEffect hook is called whenever storedFavourites or setFavourites changes. This hook checks to see if there are any items in storedFavourites, and if there are to make setFavourites (and therefore the favourites variable) equal to the same array for storedFavourites. This allows for the favourites variable to be equal to the updated array of resources.

  return (
    <View>
      <FlatList
        data={favourites}
        renderItem={({ item }) => (
          <ResourceItem
            item={item}
            favourites={favourites}
            setFavourites={setFavourites}
          />
        )}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};

// The return function for the Favourites component. This function is what the user will seen upon entering the Favourites, or favourite resources screen. It uses a Flatlist in order to display each resource saved, using the data from the favourites array and the renderItem being equal to the ResourceItem component, which defines all 3 of its props so that they can be correctly used in that component when needed. 

export default Favourites;
// exports the Favourites component, so that it can be imported in the App.js file which, by using stack navigator, will allow for the user to navigate to and from the Favourite Resources screen.