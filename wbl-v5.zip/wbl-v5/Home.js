import React from 'react';
import { View, Button, StyleSheet } from 'react-native';

//importing the appropriate tools and libraries for the home screen of the app.

const Home = ({ navigation }) => {

//The home component is defined here, which is what contains everything necessary for the home screen of the app. This is the exported later, so it can be imported to app.js and use the stack navigator so that it can be navigated to. 

  return (
    <View style={styles.container}>
      <View style ={styles.button}>
        <Button
          title="Go to Courses"
          accessibilityHint="Navigates to the courses page where you can select what course you are studying"
          onPress={() => navigation.navigate('Courses')}
        />
      </View>

      <View style ={styles.button}>
        <Button
          title="Favourite Resources"
          accessibilityHint="Navigates to the saved resources and notes that are added as favourites"
          onPress={() => navigation.navigate('Favourites')}
        />
      </View>
    </View>
  );
};

// The return function for the home screen, which contains two buttons - the first goes to the courses screen, which is where users can select which course and its subsequent modules, assignments and resources they want to view, and the second goes to the favourites screen, where the user can view any resources they saved as favourites, along with their relevant notes.

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    justifyContent: 'center',
    flex: 1,
  },

  button: {
    backgroundColor: 'white',
    fontWeight: 'bold',
    paddingVertical: 5,
    paddingHorizontal: 10,
    height: 50,
    margin: 6,
    borderWidth: 1,
    padding: 10,
    borderColor: 'black',
  },
});

// The StyleSheet for the home screen. This is used to design both the container of the whole screen, so that the buttons can appear centered on the user's device, as well as design the outline border for the buttons.

export default Home;
//exports the home component, so that it can be then imported to the app.js file and used in the stack navigator so that this screen can be navigated to by the user. This screen is also the first to appear when the user opens the app.