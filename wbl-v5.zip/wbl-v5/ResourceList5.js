import React, { useState, useEffect } from 'react';
import { Text, View, Button, TextInput, FlatList, StyleSheet} from 'react-native';
import { Linking } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

//importing the appropriate tools and libraries for this resource page of the app.

const ResourceList5 = ({ navigation, route }) => {
  const [resources, setResources] = useState([
    { id: 13, name: 'Resource 13', link: 'https://www.google.com' },
    { id: 14, name: 'Resource 14', link: 'https://www.youtube.com' },
    { id: 15, name: 'Resource 15', link: 'https://www.wikipedia.com' },
  ]);

// The resourceList5 component encapsulates the entirety of this file, and is exported at the end. This file is then imported in the app.js file, and used for the stack navigator tool so that the page will load with the functionality of this page.
// The array of resources/setResoruces holds the information of each resource, and is important in the renderItem section in order to create a flatList in ResourceList5's return value, which allows for each resource to be shown with its appropriate data. setResources is not being used here currently, but is helpful to establish in case this code would require calling this array to update or change the data inside.

  const [readResources, setReadResources] = useState({});

// Sets an empty array for resources that have been read or not. If a resource is marked as read, the resource id of that resource is saved in this array, allowing the program to know whether to mark it as read or not. Subsequently, when the "Mark all as unread" button is pressed here, it will update this array to have an empty value, thus removing the "read" status of any resource in this page.

  useEffect(() => {
    AsyncStorage.getItem('readResources')
      .then(value => {
        if (value) {
          setReadResources(JSON.parse(value));
        }
      })
      .catch(error => console.error(error));
  }, []);

  useEffect(() => {
    AsyncStorage.setItem('readResources', JSON.stringify(readResources))
      .catch(error => console.error(error));
  }, [readResources]);

//The first useEffect hook here is called when the page is mounted, and retrieves the data from the "readResources" array out from AsyncStorage. It then sets readResources using the setReadResources setting function variable to be equal to what was saved in AsyncStorage of readResources but using JSON.parse, which converts the data from a string (which is how AsyncStorage saves data) back into a javascript object.

//The second useEffect hook is called whenever the page is re-rendered, using "readResources" as a dependency so that this hook is called whenever the state of readResources is changed. This hook takes the data stored in the "readResources" array and uses JSON.stringify in order to convert that data into a string so that it can be saved in AsyncStorage.

  const { favourites, setFavourites } = route.params;

// the route.params tool in react native here allows for the favourites and setFavourites function variable names to be used outside of the Favourites.js file, without also needing to import Favourites.js into this file completely. This allows for this file, as well as the app.js file, to use these functions outside of their respective original file, and can be used to update the favourites array when needed.

  const addFavourite = (id) => {
    setFavourites((currentFavourites) => {
      const resourceToAdd = resources.find((resource) => resource.id === id);
      return [...currentFavourites, { ...resourceToAdd, notes: '' }];
    });
  };

//The function variable "addFavourite" is created with a parameter of "id". This function when called uses the setFavourites setting function variable for favourites and passes another parameter called (currentFavourites) - currentFavourites then becomes equal to the value of what the favourites array already contains, which will allow for it to be updated later with the new data. This then holds another function in which the variable "resourceToAdd" is set to be equal to the information of the resource that the user selects with the "add to favourites" button of that resource. This is achieved by using the .find functionality in the "resources" array, and by using the parameter "resource" it makes another arrow function that the "id" that is passed through in the "addFavourite" function (which would be the item id of that resource) is equal to the resource.id (the id of the resource that the .find functionality is looking for in the resources array). This then allows the "resourceToAdd" variable to be equal to the set of data in the resources array that has the same id number as the item.id of the resource that the user pressed the add to favourites button on. This function then returns "currentFavourites" (which is the parameter for the setFavourites setting variable) and adds the "resourceToAdd" to this array, which in turn using setFavourites adds this new data to the current favourites array as well. This then means that whenever the button "add to Favourites" is pressed, that resource's data found using its item id is then added to the favourites array, which then allows it to be viewed and accessed in the saved resources and notes page of the app on the home screen.

  const markAsRead = (id) => {
    setReadResources((currentReadResources) => {
      return {...currentReadResources, [id]: true};
    });
  };

  const markAllAsUnread = () => {
    setReadResources({});
  };

//the markAsRead function is called whenever the "Mark as Read" button is pressed - this will only occur if the user has not already pressed the button. Once the button is pressed, the function is called and the item.id (the id of that resource) is passed as a parameter to allow for the readResources array to be updated with that resource's id. When the renderItem function is called for the flatList, it will check using readResources and the item.id as its parameter whether or not that resource's id exists in the readResources array. If it does (the value is set to True), then the button will display that it has been "Read" and the user cannot press the button again - otherwise, it will display "Mark as Read".

//The markAllAsUnread function is called whenever the user presses the "Mark all as Unread" button in this resource page. When the button is pressed, this function is called and simply updates the readResources array (using the setReadResources variable name to update it) to have an empty value - therefore when this happens, there are no more resource ids in the array and so the button for "Mark as Read" is set back to its default again on this page.

  const renderItem = ({ item }) => (
    <View style={styles.container}>
      <View>
        <Text style={styles.resourceName}>
        {item.name}
        </Text>
      </View>

      <View style={styles.button}>
      {readResources[item.id] ? (
        <Button title="Read" accessibilityHint="This resource has been marked as Read" disabled={true} />
      ) : (
        <Button title="Mark as Read" accessibilityHint="Marks this resource as being read, so the user can remember which resources they have interacted with already." onPress={() => markAsRead(item.id)} />
      )}
      </View>
      <View style={styles.button}>
        <Button title={item.link} accessibilityHint="Opens the URL Link for this resource" onPress={() => Linking.openURL(item.link)} />
      </View>

      <View style={styles.button}>
        <Button title="Add to favourites" accessibilityHint="Marks this resource as a favourite and saves it to the saved resources page, which is available on the home page." onPress={() => addFavourite(item.id)} />
      </View>
    </View>
  );

//The renderItem component is what each resource will use to allow for it to be viewed and have functionality. When the Flatlist is made in the return function below, it uses the data from "resources" to define what data will be passed through, and calls this component, "renderItem", to display this data. It also uses a keyExtractor which sets the unique key for each item in "resources" to be each resources' id, which is then used by renderItem as a parameter to know which data to display and how many need to be displayed in total. This renderItem includes displaying the name of the resource, the button/s for marking a resource as "read", opening the URL link for that resource, as well as the button that adds a resource to the favourite resources page, using the addFavourite function.

  return (
    <View style={styles.background}>
      <View style={styles.button}>
        <Button title="Mark All as Unread" color='red' accessibilityHint="Marks all resources on the app as unread" onPress={markAllAsUnread} />
      </View>
      <FlatList
        data={resources}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};

// The return function here returns the value of the ResourceList5 component, which includes the button for marking all resources as unread, as well as the FlatList that contains and renders each resource. This return function is what the user will actually be able to view, and acts as the front interface of the page itself.

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  resourceName: {
    marginTop: 2,
    paddingVertical: 8,
    borderWidth: 3,
    borderColor: 'black',
    borderRadius: 3,
    backgroundColor: 'black',
    color: 'white',
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: 'white',
    fontWeight: 'bold',
    paddingVertical: 5,
    paddingHorizontal: 10,
    height: 50,
    margin: 3,
    borderWidth: 1,
    padding: 5,
  },

  background: {
    backgroundColor: 'white',
  }
});

//The stylesheet for this resourceList. It contains all styles and designs for this screen of the app, including colour, size, text size and how far certain objects will be spaced out from one another.

export default ResourceList5;
//exports the ResourceList5 component, so that it can be imported in App.js and used in the Stack Navigator tool to allow for users to go to this page.