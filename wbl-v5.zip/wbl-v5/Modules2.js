import React from 'react';
import { View, Button, StyleSheet } from 'react-native';

//importing the appropriate tools and libraries for one of the module screens of the app.

const Modules2 = ({ navigation }) => {

//The Modules2 component is defined here, which is what contains everything necessary for this module screen of the app. This is the exported later, so it can be imported to app.js and use the stack navigator so that it can be navigated to. 

  return (
    <View style={styles.container}>
      <View style={styles.button}>
        <Button
          title="Module 1 - Networking 1"
          accessibilityHint="Takes you to the first networking module page and its relevant assignments"
          onPress={() => navigation.navigate('Networking Module 1')}
        />
      </View>

      <View style={styles.button}>
        <Button
          title="Module 2 - Networking 2"
          accessibilityHint="Takes you to the second networking module page and its relevant assignments"
          onPress={() => navigation.navigate('Networking Module 2')}
        />
      </View>
    </View>
  );
};

//The return function for this module screen. This will display two buttons, with the first navigating the user to Module 1 of the networking course, and the second navigating to Module 2 of the networking course. These will then navigate to the relevant assignment screen, which will show the user that module's relevant assignments.

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    justifyContent: 'center',
    flex: 1,
  },

  button: {
    backgroundColor: 'white',
    fontWeight: 'bold',
    paddingVertical: 5,
    paddingHorizontal: 10,
    height: 50,
    margin: 6,
    borderWidth: 1,
    padding: 10,
    borderColor: 'black',
  },
});

// The StyleSheet for this module screen. It shares identical design to the other module screen, as well as the home screen of the app. This is so that the design of the app can stay consistent and simple throughout its use.

export default Modules2;
//exports the Modules2 component, which is then imported into the App.js file so that it can be used in the stack navigator there to allow the user to navigate to and from this page when called on.