import React, { useState, useEffect } from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

//importing the appropriate tools and libraries for the courses screen of the app.

const Courses = ({ navigation }) => {
  const [selectedCourse, setSelectedCourse] = useState({});

// The Courses component is defined here, which encompasses this screen. This is later exported so that it can then be imported in the App.js file. 
// The selectedCourse variable and its accompanying setSelectedCourse setting function variable is defined as an empty array, which will hold the data needed so that the courses screen knows which course has been marked as the user's favourite, and display this as such when needed.

  useEffect(() => {
    const getSelectedCourse = async () => {
      const course = await AsyncStorage.getItem('selectedCourse');
      setSelectedCourse(course);
    }
    getSelectedCourse();
  }, []);

// This useEffect hook is called when the component is mounted, and is used to retrieve the data stored in the "selectedCourse" array from AsyncStorage.

  const handleCourseSelection = async (course) => {
    setSelectedCourse(course);
    await AsyncStorage.setItem('selectedCourse', course);
  };

  const handleReset = async () => {
    setSelectedCourse(null);
    await AsyncStorage.removeItem('selectedCourse');
  };

//The function variable "handleCourseSelection" is called when the "select as favourite course" button is pressed, and neither button for each course has already been selected. When called, it passes a parameter (course) which is equal to the course name that was selected to be the favourite course of the user. This then sets the selectedCourse array to include the data of the parameter given using the "setSelectedCourse" function variable, which is used later on to disable the buttons for the course that was not selected.

// The function variable "handleReset" is called when the "reset" button is pressed by the user.  This sets the selectedCourse array to be null, and the data that is persisted in AsyncStorage is then also set to be "null", using the .removeItem functionality. This allows for a clean reset of the course selected as the user's favourite, so that it can be re-assigned at the user's leisure.

  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.mainText}>
          You can select a course as your "favourite" in order to allow access to only the course that you are studying.
        </Text>
      </View>

      <View>
        <Text style={styles.courseName}>
          Course 1 - Software Development
        </Text>
      </View>

      <View style={styles.button}>
        <Button
          title="Go to Course"
          accessibilityHint="Takes you to the software course page, containing its appropriate modules"
          onPress={() => navigation.navigate(`Software Course`)}
          disabled={selectedCourse === 'course2'}
        />
      </View>

      <View style={styles.button}>
        {selectedCourse ? (
          <Button
          title="A course has already been selected"
          disabled={true}
        />
        ) : (
        <Button
          title="Select as favourite course"
          accessibilityHint="Press to select this as your current course - this will make other courses unavailable to view until reset"
          onPress={() => handleCourseSelection('course1')}
          disabled={selectedCourse === 'course2'}
        />
        )}
      </View>

      <View>
        <Text style={styles.courseName}>
          Course 2 - Networking
        </Text>
      </View>

      <View style={styles.button}>
        <Button
          title="Go to Course"
          accessibilityHint="Takes you to the networking course page, containing its appropriate modules"
          onPress={() => navigation.navigate(`Networking Course`)}
          disabled={selectedCourse === 'course1'}

        />
      </View>

      <View style={styles.button}>
        {selectedCourse ? (
          <Button
          title="A course has already been selected"
          disabled={true}
        />
        ) : (
        <Button
          title="Select as favourite course"
          accessibilityHint="Press to select this as your current course - this will make other courses unavailable to view until reset"
          onPress={() => handleCourseSelection('course2')}
          disabled={selectedCourse === 'course1'}
        />
        )}
      </View>

      <View>
        {selectedCourse && (
          <View style={styles.resetButton}>
            <Button
              title="Reset"
              color="red"
              accessibilityHint="Resets what course you have selected, allowing you to select again which course you are studying"
              onPress={() => handleReset()}
            />
          </View>
        )}
      </View>
    </View>
  );
};

// The return function for the Courses component. This handles what the user will be able to view and interact with when navigated to this screen. It holds the buttons for each course that when pressed navigate to their corresponding "modules" screen, where the user can select the modules present in that course. It also contains the buttons to allow the user to select a favourite course, which can be pressed and disable the other courses' buttons, so that the user has greater choice over what content they wish to view. It also contains the button for resetting this option, which will only appear once the user has already selected a course as their favourite. 

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  courseName: {
    marginTop: 16,
    paddingVertical: 8,
    borderWidth: 3,
    borderColor: 'black',
    borderRadius: 3,
    backgroundColor: 'white',
    color: 'black',
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: 'white',
    fontWeight: 'bold',
    paddingVertical: 5,
    paddingHorizontal: 10,
    height: 50,
    margin: 6,
    borderWidth: 1,
    padding: 10,
  },

  resetButton: {
    backgroundColor: 'white',
    fontWeight: 'bold',
    paddingVertical: 5,
    paddingHorizontal: 10,
    height: 50,
    margin: 6,
    borderWidth: 1,
    padding: 10,
    borderColor: 'red',
  },

  mainText: {
    textAlign: 'center',
    textSize: 26,
    padding: 15,
  }
});

//The StyleSheet for the Courses screen. This contains the aesthetic designs for the regular buttons, as well as a seperate design for the reset button which denotes a different colour scheme, informing the user that it performs a clear, different action than the other buttons presented. This stylesheet also controls the font size of the main text of the app and the course names, as well as creating borders for the buttons to better seperate them from each other.

export default Courses;
// exports the Courses component, so that it can be imported into the App.js file and, by using the Stack Navigator, allow the user to navigate to and from this screen.