import React from 'react';
import { View, Button, StyleSheet } from 'react-native';

//importing the appropriate tools and libraries for one of the assignment screens of the app.

const Assignments4 = ({ navigation }) => {

//The Assignments4 component is defined here, which is what contains everything necessary for this assignment screen of the app. This is the exported later, so it can be imported to app.js and use the stack navigator so that it can be navigated to. 

  return (
    <View style={styles.container}>
      <View style={styles.button}>
        <Button
          title="Assignment 1"
          accessibilityHint="Navigates to the list of resources for assignment 1 of this module"
          onPress={() => navigation.navigate('Resource List 7')}
        />
      </View>

      <View style={styles.button}>
        <Button
          title="Assignment 2"
          accessibilityHint="Navigates to the list of resources for assignment 2 of this module"
          onPress={() => navigation.navigate('Resource List 8')}
        />
      </View>
    </View>
  );
};

//The return function for this assigmnent screen. This will display two buttons, with the first navigating the user to the resources of the first assignment, and the second navigating to the resources of the second assignment.

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    justifyContent: 'center',
    flex: 1,
  },

  button: {
    backgroundColor: 'white',
    fontWeight: 'bold',
    paddingVertical: 5,
    paddingHorizontal: 10,
    height: 50,
    margin: 6,
    borderWidth: 1,
    padding: 10,
    borderColor: 'black',
  },
});

// The StyleSheet for this assignment screen. It shares identical design to the other assignments screens, as well as the module screens and home screen of the app. This is so that the design of the app can stay consistent and simple throughout its use.

export default Assignments4;
//exports the Assignments4 component, which is then imported into the App.js file so that it can be used in the stack navigator there to allow the user to navigate to and from this page when called on.