import React, { useState } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from './Home';
import ResourceList1 from './ResourceList1';
import ResourceList2 from './ResourceList2';
import ResourceList3 from './ResourceList3';
import ResourceList4 from './ResourceList4';
import ResourceList5 from './ResourceList5';
import ResourceList6 from './ResourceList6';
import ResourceList7 from './ResourceList7';
import ResourceList8 from './ResourceList8';
import Assignments1 from './Assignments1';
import Assignments2 from './Assignments2';
import Assignments3 from './Assignments3';
import Assignments4 from './Assignments4';
import Favourites from './Favourites';
import Courses from './Courses';
import Modules1 from './Modules1';
import Modules2 from './Modules2';

// Importing all necessary libraries, including stack navigator in order to create multiple pages. It also imports the other files in this app, each one representing different pages, and each with their own functionalities. Having these in seperate files allows for the program to be more readable and easier to find where different parts of the app are being controlled and located.

const Stack = createStackNavigator();

// defines the variable "Stack" as the createStackNavigator tool. This is what contains all the screens of the app and allows for navigation to happen between them.

export default function App() {
  const [favourites, setFavourites] = useState([]);

//the useState hook is used here to create a variable "favourites" and a function "setFavourites" that allows for the favourites variable to be updated as needed. The useState allows for managing the list of favourite resources that the user can add or remove from - in particular, allowing for this list of resources to be managed between screens.

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Courses" component={Courses} />
        <Stack.Screen name="Software Course" component={Modules1} />
        <Stack.Screen name="Networking Course" component={Modules2} />
        <Stack.Screen name="Software Module 1" component={Assignments1} />
        <Stack.Screen name="Software Module 2" component={Assignments2} />
        <Stack.Screen name="Networking Module 1" component={Assignments3} />
        <Stack.Screen name="Networking Module 2" component={Assignments4} />
        <Stack.Screen name="Resource List 1" component={ResourceList1} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 2" component={ResourceList2} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 3" component={ResourceList3} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 4" component={ResourceList4} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 5" component={ResourceList5} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 6" component={ResourceList6} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 7" component={ResourceList7} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 8" component={ResourceList8} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Favourites" component={Favourites} initialParams={{ favourites, setFavourites }}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

//The return statement for the "app" function - this is where each page or "screen" of the app is added. Each screen has a name and a component that are used to refer to other files in the program, with each file representing a different page that are imported from the imports at the top of this file, and then referenced via the component, whilst the "name" of each screen references the name of the main function of each page/file that is exported.