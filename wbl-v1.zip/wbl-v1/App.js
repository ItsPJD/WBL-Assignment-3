import React, { useState } from 'react';
import { Text, View, Button, TextInput, FlatList, TouchableOpacity } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';

const Stack = createStackNavigator();

const ResourceList = ({ navigation }) => {
  const [resources, setResources] = useState([
    { id: 1, name: 'Resource 1', link: 'https://www.resource1.com' },
    { id: 2, name: 'Resource 2', link: 'https://www.resource2.com' },
    { id: 3, name: 'Resource 3', link: 'https://www.resource3.com' },
  ]);

  const [favourites, setFavourites] = useState([]);

  const addFavourite = (id) => {
    const resourceToAdd = resources.find((resource) => resource.id === id);
    setFavourites([...favourites, { ...resourceToAdd, notes: '' }]);
  };

  const renderItem = ({ item }) => (
    <View style={{ flexDirection: 'row'}}>
      <View style={{ flex: 1 }}>
        <Text>{item.name}</Text>
        <Text>{item.link}</Text>
      </View>
      <Button title="Add to favourites" onPress={() => addFavourite(item.id)} />
    </View>
  );

  return (
    <View>
      <FlatList
        data={resources}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
      <Button
        title="View Favourites"
        onPress={() => navigation.navigate('Favourites', { favourites: favourites, setFavourites: setFavourites })}
      />
    </View>
  );
};

const Favourites = ({ route }) => {
  const { favourites, setFavourites } = route.params;

  const [notes, setNotes] = useState({});

  const handleNotesChange = (id, text) => {
    setNotes({
      ...notes,
      [id]: text,
    });
  };

  const handleDelete = (id) => {
    const updatedFavourites = favourites.filter((resource) => resource.id !== id);
    setFavourites(updatedFavourites);

    const updatedNotes = { ...notes };
    delete updatedNotes[id];
    setNotes(updatedNotes);
  };

  const renderItem=({ item }) => (
    <View style={{ marginBottom: 10 }}>
      <Text>{item.name}</Text>
      <Text>{item.link}</Text>
      <TextInput
        placeholder="Add notes here"
        onChangeText={(text) => handleNotesChange(item.id, text)}
        value={notes[item.id] || ''}
        style={{ borderWidth: 1, borderColor: 'gray', borderRadius: 5, padding: 5, marginTop: 5 }}
      />
      <TouchableOpacity onPress={() => handleDelete(item.id)}>
        <Text>Delete</Text>
      </TouchableOpacity>
    </View>
        )

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: 20, marginBottom: 20 }}>Favourites</Text>
      <FlatList
        data={favourites}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Resource List" component={ResourceList} />
        <Stack.Screen name="Favourites" component={Favourites} />
      </Stack.Navigator>
    </NavigationContainer>   
  );
}

