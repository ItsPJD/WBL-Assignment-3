import React from 'react';
import { View, Button } from 'react-native';

const Modules1 = ({ navigation }) => {
  return (
    <View>
      <Button
        title="Module 1 - Software 1"
        onPress={() => navigation.navigate('Resource List 1')}
      />
      <Button
        title="Module 2 - Software 2"
        onPress={() => navigation.navigate('Resource List 2')}
      />
    </View>
  );
};

export default Modules1;