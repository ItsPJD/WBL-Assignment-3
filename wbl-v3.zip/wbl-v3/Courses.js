import React from 'react';
import { View, Button } from 'react-native';

const Courses = ({ navigation }) => {
  return (
    <View>
      <Button
        title="Course 1 - Software Development"
        onPress={() => navigation.navigate('Modules1')}
      />
      <Button
        title="Course 2 - Networking"
        onPress={() => navigation.navigate('Modules2')}
      />
    </View>
  );
};

export default Courses;