import React, { useState } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from './Home';
import ResourceList1 from './ResourceList1';
import ResourceList2 from './ResourceList2';
import ResourceList3 from './ResourceList3';
import ResourceList4 from './ResourceList4';
import Favourites from './Favourites';
import Courses from './Courses';
import Modules1 from './Modules1';
import Modules2 from './Modules2';
import ResourceList from './ResourceList';

const Stack = createStackNavigator();

export default function App() {
  const [favourites, setFavourites] = useState([]);

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Courses" component={Courses} />
        <Stack.Screen name="Modules1" component={Modules1} />
        <Stack.Screen name="Modules2" component={Modules2} />
        <Stack.Screen name="Resource List" component={ResourceList} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 1" component={ResourceList1} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 2" component={ResourceList2} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 3" component={ResourceList3} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Resource List 4" component={ResourceList4} initialParams={{ favourites, setFavourites }}/>
        <Stack.Screen name="Favourites" component={Favourites} initialParams={{ favourites, setFavourites }}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
