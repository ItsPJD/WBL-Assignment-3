import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, FlatList } from 'react-native';
import { Linking } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ResourceItem = ({ item, favourites, setFavourites }) => {
  const [tempNotes, setTempNotes] = useState(item.notes);

  const updateNotes = () => {
    const updatedFavourites = favourites.map((favourite) => {
      if (favourite.id === item.id) {
        return { ...favourite, notes: tempNotes };
      }
      return favourite;
    });
    setFavourites(updatedFavourites);
    AsyncStorage.setItem('favourites', JSON.stringify(updatedFavourites));
  };
 
  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.resourceName}>{item.name}</Text>
        <Button
          style={styles.resourceLink}
          title={item.link}
          onPress={() => Linking.openURL(item.link)}
        />
      </View>
      <View style={{ flexDirection: 'column', alignItems: 'center' }}>
        <TextInput
          style={styles.resourceNotesInput}
          placeholder="Add note"
          value={tempNotes}
          onBlur={updateNotes}
          onChangeText={(text) => setTempNotes(text)}
          multiline={true}
          numberOfLines={6}
          textAlignVertical="top"
        />
        <Button
          style={styles.deleteButton}
          title="Delete"
          onPress={() => {
            const updatedFavourites = favourites.filter(
              (favourite) => favourite.id !== item.id
            );
            setFavourites(updatedFavourites);
            AsyncStorage.setItem('favourites', JSON.stringify(updatedFavourites));
          }}
        />
      </View>
    </View>
  );
};

const Favourites = ({ route }) => {
  const { favourites, setFavourites } = route.params;
  const [storedFavourites, setStoredFavourites] = useState([]);

  const loadFavourites = async () => {
    const storedFavourites = await AsyncStorage.getItem('favourites');
    if (storedFavourites) {
      setStoredFavourites(JSON.parse(storedFavourites));
    }
  };

  useEffect(() => {
    loadFavourites();
  }, []);

  useEffect(() => {
    if (storedFavourites.length > 0) {
      setFavourites(storedFavourites);
    }
  }, [storedFavourites, setFavourites]);

  return (
    <View>
      <FlatList
        data={favourites}
        renderItem={({ item }) => (
          <ResourceItem
            item={item}
            favourites={favourites}
            setFavourites={setFavourites}
          />
        )}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  resourceName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    justifyContent: 'center',
  },
  resourceLink: {
    color: 'blue',
    marginBottom: 5,
  },
  resourceNotesInput: {
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 5,
    paddingHorizontal: 10,
  },
  deleteButton: {
    backgroundColor: 'red',
    color: 'white',
    fontWeight: 'bold',
    paddingVertical: 5,
    paddingHorizontal: 10,
  },
});

export default Favourites;