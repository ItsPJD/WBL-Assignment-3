import React from 'react';
import { View, Button } from 'react-native';

const Home = ({ navigation }) => {

  return (
    <View>
      <Button
        title="Go to Courses"
        onPress={() => navigation.navigate('Courses')}
      />
      <Button
        title="Favourite Resources"
        onPress={() => navigation.navigate('Favourites')}
      />
    </View>
  );
};

export default Home;