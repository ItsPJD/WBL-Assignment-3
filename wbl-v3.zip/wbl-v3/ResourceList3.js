import React, { useState, useEffect } from 'react';
import { Text, View, Button, TextInput, FlatList} from 'react-native';
import { Linking } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ResourceList3 = ({ navigation, route }) => {
  const [resources, setResources] = useState([
    { id: 7, name: 'Resource 7', link: 'https://www.google.com' },
    { id: 8, name: 'Resource 8', link: 'https://www.youtube.com' },
    { id: 9, name: 'Resource 9', link: 'https://www.wikipedia.com' },
  ]);
  const [readResources, setReadResources] = useState({});

  useEffect(() => {
    AsyncStorage.getItem('readResources')
      .then(value => {
        if (value) {
          setReadResources(JSON.parse(value));
        }
      })
      .catch(error => console.error(error));
  }, []);

  useEffect(() => {
    AsyncStorage.setItem('readResources', JSON.stringify(readResources))
      .catch(error => console.error(error));
  }, [readResources]);

  const { favourites, setFavourites } = route.params;

  const addFavourite = (id) => {
    setFavourites((currentFavourites) => {
      const resourceToAdd = resources.find((resource) => resource.id === id);
      return [...currentFavourites, { ...resourceToAdd, notes: '' }];
    });
  };

  const markAsRead = (id) => {
    setReadResources((currentReadResources) => {
      return {...currentReadResources, [id]: true};
    });
  };

  const markAllAsUnread = () => {
    setReadResources({});
  };

  const renderItem = ({ item }) => (
    <View style={{ flexDirection: 'column'}}>
      <View style={{ flex: 1 }}>
        <Text>{item.name}</Text>
        <Text>{item.link}</Text>
      </View>
      {readResources[item.id] ? (
        <Button title="Read" disabled={true} />
      ) : (
        <Button title="Mark as Read" onPress={() => markAsRead(item.id)} />
      )}
      <Button title="Visit" onPress={() => Linking.openURL(item.link)} />
      <Button title="Add to favourites" onPress={() => addFavourite(item.id)} />
    </View>
  );

  return (
    <View>
      <Button title="Mark All as Unread" onPress={markAllAsUnread} />
      <FlatList
        data={resources}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};

export default ResourceList3;